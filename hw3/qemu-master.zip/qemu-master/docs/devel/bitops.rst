==================
Bitwise operations
==================

The header ``qemu/bitops.h`` provides utility functions for
performing bitwise operations.

.. kernel-doc:: include/qemu/bitops.h
