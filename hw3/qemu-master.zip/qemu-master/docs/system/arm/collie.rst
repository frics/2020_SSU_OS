Sharp Zaurus SL-5500 (``collie``)
=================================

This machine is a model of the Sharp Zaurus SL-5500, which was
a 1990s PDA based on the StrongARM SA1110.

Implemented devices:

 * NOR flash
 * Interrupt controller
 * Timer
 * RTC
 * GPIO
 * Peripheral Pin Controller (PPC)
 * UARTs
 * Synchronous Serial Ports (SSP)
