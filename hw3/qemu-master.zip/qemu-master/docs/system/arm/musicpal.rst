Freecom MusicPal (``musicpal``)
===============================

The Freecom MusicPal internet radio emulation includes the following
elements:

-  Marvell MV88W8618 Arm core.

-  32 MB RAM, 256 KB SRAM, 8 MB flash.

-  Up to 2 16550 UARTs

-  MV88W8xx8 Ethernet controller

-  MV88W8618 audio controller, WM8750 CODEC and mixer

-  128x64 display with brightness control

-  2 buttons, 2 navigation wheels with button function
