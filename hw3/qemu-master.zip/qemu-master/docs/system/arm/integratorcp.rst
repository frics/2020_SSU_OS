Arm Integrator/CP (``integratorcp``)
====================================

The Arm Integrator/CP board is emulated with the following devices:

-  ARM926E, ARM1026E, ARM946E, ARM1136 or Cortex-A8 CPU

-  Two PL011 UARTs

-  SMC 91c111 Ethernet adapter

-  PL110 LCD controller

-  PL050 KMI with PS/2 keyboard and mouse.

-  PL181 MultiMedia Card Interface with SD card.
